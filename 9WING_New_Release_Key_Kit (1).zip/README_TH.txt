9WING.PRO — NEW RELEASE KEY INSTALL (2026)
==========================================
นี่คือคีย์เซ็นแอปที่สร้างใหม่ ไม่ใช่คีย์ Release เดิม

ลงไฟล์ในโฟลเดอร์โปรเจกต์ G:\9WING_Common_Medicine\
    9WING_RELEASE_NEW_2026.jks
    9wing_release_signing.properties
    app\build.gradle          (ให้สำรองไฟล์เดิมก่อนแล้วแทนที่ด้วยไฟล์ในชุดนี้)

จากนั้น Android Studio -> Sync Project with Gradle Files -> Build Release.

Alias: android
Keystore format: JKS
Algorithm: RSA 3072 / SHA256withRSA
SHA-256 certificate fingerprint: FF804ABEBCECD66BFDAE0FFA4D8957D1A3210D3AAC0F0ABB69FD023B6D998E84

คำเตือนสำคัญ
1. ลายเซ็นใหม่นี้จะไม่สามารถติดตั้งทับแอปที่เซ็นด้วยคีย์เดิมได้
2. ถ้าติดตั้งใหม่หลังถอนแอปเดิม ข้อมูลในเครื่องของแอปเดิมอาจสูญหาย ให้สำรองไว้ก่อน
3. โปรเจกต์ที่แจกจ่ายหรืออัปโหลดขึ้น Git ห้ามมี .jks และ signing.properties
4. สำรองไฟล์ JKS กับรหัสผ่านในที่ปลอดภัย หากสูญหายจะไม่สามารถออกอัปเดตด้วยคีย์นี้ได้
5. Release signing guard และ AppIntegrityGuard ยังคงทำงาน เพียงปรับลายเซ็นคาดหวังให้ตรงกับคีย์ใหม่
6. ชุดนี้ไม่ได้แสดงว่ามีการ Build APK แล้ว คุณต้อง Build ใน Android Studio เอง
